# SIMPEL Rancanumpang
Sistem Informasi Manajemen Pelayanan Kelurahan Rancanumpang, Kecamatan Gedebage.

Aplikasi Android (Kotlin + Jetpack Compose + Room) hasil implementasi dari dokumen
**Analisis Sistem Kelurahan Rancanumpang Kecamatan Gedebage** (Use Case Diagram &
Use Case Scenario, Bab III — Analisis Sistem Perbaikan).

## Cara Menjalankan
1. Buka folder ini di **Android Studio** (Koala/Jellyfish ke atas) → `Open` → pilih folder `SimpelRancanumpang`.
2. Biarkan Android Studio melakukan Gradle Sync (akan mengunduh dependency Compose, Room, Navigation).
3. Jalankan pada emulator/perangkat dengan **Run ▶**.
4. Tidak memerlukan backend/server — seluruh data disimpan lokal memakai **Room (SQLite)**, dan sudah diisi data contoh (seed) saat pertama kali aplikasi dijalankan.

## Akun Demo (password semua: `1234`)
| Username     | Peran (Aktor)                  |
|--------------|---------------------------------|
| warga1       | Warga (NIK terdaftar)           |
| warga2       | Warga (NIK terdaftar, kategori PMKS) |
| kasipem      | Kasi Pemerintahan                |
| kasikesos    | Kasi Kesejahteraan Sosial        |
| kasiekbang   | Kasi Ekonomi Pembangunan          |
| petugas1     | Petugas Lapangan Kelurahan        |
| lurah        | Lurah                             |

## Pemetaan Use Case ke Fitur Aplikasi

| Use Case (dari dokumen)                         | Fitur di Aplikasi |
|--------------------------------------------------|--------------------|
| Login                                             | `LoginScreen` — autentikasi per peran |
| Permohonan Surat Keterangan / Pengurusan KTP-KK / Surat Domisili / SKTM / UMKM | `FormPengajuanScreen` — Warga memilih jenis layanan & mengajukan |
| Verifikasi Data Warga (otomasi verifikasi NIK)    | `Repository.ajukanPermohonan()` — NIK dicocokkan otomatis ke `data_warga` (basis data kependudukan lokal) |
| Input & Kelola Data / Kelola Data Penugasan       | `KasiHomeScreen` + `DetailVerifikasiScreen` — Kasi memverifikasi & mendisposisikan ke petugas |
| Kelola Data Hasil (verifikasi lapangan)           | `PetugasHomeScreen` + `DetailTugasScreen` — Petugas mengisi hasil pemeriksaan lapangan |
| Tanda Tangan Surat / Persetujuan Pengaduan (validasi Lurah) | `LurahHomeScreen` + `DetailValidasiScreen` — Lurah menyetujui/menolak berkas |
| Transparansi Pelacakan Berkas (nomor resi)        | `LacakStatusScreen` — Warga melacak status dengan nomor resi |
| Kelola Data Laporan (kompilasi laporan bulanan)   | `LaporanBulananScreen` — rekap otomatis per jenis layanan & status, per bulan berjalan |

## Alur Status Permohonan
`Diajukan → Terverifikasi NIK (atau NIK Tidak Valid) → Didisposisikan ke Petugas →
Menunggu Validasi Lurah → Disetujui Lurah / Ditolak Lurah → Selesai / Dokumen Diterbitkan`

## Struktur Proyek
```
app/src/main/java/com/rancanumpang/simpel/
├── data/          # Entity, DAO, Room Database, Repository (data & logika verifikasi NIK)
├── viewmodel/     # AuthViewModel, PermohonanViewModel, ViewModelFactory
├── navigation/     # Routes & NavGraph (Jetpack Navigation Compose)
└── ui/
    ├── theme/      # Tema Material3
    └── screens/    # Seluruh layar Compose per aktor (Warga, Kasi, Petugas, Lurah)
```

## Catatan
- Aplikasi ini adalah implementasi tahap pengodean (sesuai saran Bab IV) dari
  rancangan UML pada laporan: Use Case Diagram, Use Case Scenario, Activity Diagram,
  Sequence Diagram, dan Class Diagram.
- Untuk kebutuhan produksi nyata, database lokal (Room) dapat digantikan/disinkronkan
  dengan database relasional server (MySQL/MariaDB) sesuai saran pada laporan (Bab IV.2),
  memakai REST API sebagai penghubung.
