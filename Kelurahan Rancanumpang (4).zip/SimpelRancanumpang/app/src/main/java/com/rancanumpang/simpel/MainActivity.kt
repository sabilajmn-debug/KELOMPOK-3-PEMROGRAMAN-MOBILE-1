package com.rancanumpang.simpel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.lifecycleScope
import com.rancanumpang.simpel.data.AppDatabase
import com.rancanumpang.simpel.data.Repository
import com.rancanumpang.simpel.navigation.AppNavGraph
import com.rancanumpang.simpel.ui.theme.SimpelTheme
import com.rancanumpang.simpel.viewmodel.AuthViewModel
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel
import com.rancanumpang.simpel.viewmodel.ViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val database = AppDatabase.getInstance(applicationContext, lifecycleScope)
        val repository = Repository(database)
        val factory = ViewModelFactory(repository)

        setContent {
            SimpelTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SimpelApp(factory = factory)
                }
            }
        }
    }
}

@Composable
fun SimpelApp(factory: ViewModelFactory) {
    val authViewModel: AuthViewModel = viewModel(factory = factory)
    val permohonanViewModel: PermohonanViewModel = viewModel(factory = factory)
    AppNavGraph(authViewModel = authViewModel, permohonanViewModel = permohonanViewModel)
}
