package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.StatusPermohonan
import com.rancanumpang.simpel.data.UserAccount
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetugasHomeScreen(
    user: UserAccount,
    viewModel: PermohonanViewModel,
    onOpenDetail: (Long) -> Unit,
    onLogout: () -> Unit
) {
    val semua by viewModel.semuaPermohonan.collectAsState()
    val tugasSaya = remember(semua, user.username) {
        semua.filter { it.petugasDitugaskan == user.username }
    }
    val menunggu = tugasSaya.filter { it.status == StatusPermohonan.DISPOSISI_PETUGAS }
    val selesai = tugasSaya.filter { it.status != StatusPermohonan.DISPOSISI_PETUGAS }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Beranda Petugas") },
                actions = { TextButton(onClick = onLogout) { Text("Keluar") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Halo, ${user.nama}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))

            Text("Tugas Perlu Diverifikasi (${menunggu.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (menunggu.isEmpty()) {
                Text("Tidak ada tugas baru.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(menunggu) { p ->
                        Card(onClick = { onOpenDetail(p.id) }) {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.jenisLayanan.label, fontWeight = FontWeight.SemiBold)
                                Text("Pemohon: ${p.namaPemohon}", style = MaterialTheme.typography.bodySmall)
                                if (!p.catatanKasi.isNullOrBlank()) {
                                    Text("Catatan Kasi: ${p.catatanKasi}", style = MaterialTheme.typography.bodySmall)
                                }
                                Spacer(Modifier.height(6.dp))
                                StatusBadge(status = p.status)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Riwayat Tugas Selesai (${selesai.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (selesai.isEmpty()) {
                Text("Belum ada riwayat.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(selesai) { p ->
                        Card {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.jenisLayanan.label, fontWeight = FontWeight.SemiBold)
                                Text("Pemohon: ${p.namaPemohon}", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(6.dp))
                                StatusBadge(status = p.status)
                            }
                        }
                    }
                }
            }
        }
    }
}
