package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.UserAccount
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WargaHomeScreen(
    user: UserAccount,
    viewModel: PermohonanViewModel,
    onAjukan: () -> Unit,
    onLacak: () -> Unit,
    onLogout: () -> Unit
) {
    LaunchedEffect(user.nik) {
        user.nik?.let { viewModel.muatPermohonanWarga(it) }
    }
    val daftar by viewModel.permohonanSaya.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Beranda Warga") },
                actions = {
                    TextButton(onClick = onLogout) { Text("Keluar") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Halo, ${user.nama}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("NIK: ${user.nik}", style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onAjukan, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Ajukan Surat")
                }
                OutlinedButton(onClick = onLacak, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Search, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Lacak Status")
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Riwayat Permohonan Saya", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (daftar.isEmpty()) {
                Text("Belum ada permohonan yang diajukan.", style = MaterialTheme.typography.bodyMedium)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(daftar) { p ->
                        Card {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.jenisLayanan.label, fontWeight = FontWeight.SemiBold)
                                Text("No. Resi: ${p.nomorResi}", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())
                                        .format(Date(p.tanggalPengajuan)),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Spacer(Modifier.height(6.dp))
                                StatusBadge(status = p.status)
                            }
                        }
                    }
                }
            }
        }
    }
}
