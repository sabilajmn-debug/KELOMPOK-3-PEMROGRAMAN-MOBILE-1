package com.rancanumpang.simpel.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(users: List<UserAccount>)

    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    suspend fun login(username: String, password: String): UserAccount?

    @Query("SELECT * FROM users")
    fun getAll(): Flow<List<UserAccount>>
}

@Dao
interface DataWargaDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(list: List<DataWarga>)

    @Query("SELECT * FROM data_warga WHERE nik = :nik LIMIT 1")
    suspend fun findByNik(nik: String): DataWarga?

    @Query("SELECT * FROM data_warga")
    fun getAll(): Flow<List<DataWarga>>
}

@Dao
interface PermohonanDao {
    @Insert
    suspend fun insert(permohonan: Permohonan): Long

    @Update
    suspend fun update(permohonan: Permohonan)

    @Query("SELECT * FROM permohonan ORDER BY tanggalPengajuan DESC")
    fun getAll(): Flow<List<Permohonan>>

    @Query("SELECT * FROM permohonan WHERE nik = :nik ORDER BY tanggalPengajuan DESC")
    fun getByNik(nik: String): Flow<List<Permohonan>>

    @Query("SELECT * FROM permohonan WHERE nomorResi = :resi LIMIT 1")
    suspend fun getByResi(resi: String): Permohonan?

    @Query("SELECT * FROM permohonan WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Permohonan?

    @Query("SELECT * FROM permohonan WHERE petugasDitugaskan = :petugas ORDER BY tanggalPengajuan DESC")
    fun getByPetugas(petugas: String): Flow<List<Permohonan>>
}
