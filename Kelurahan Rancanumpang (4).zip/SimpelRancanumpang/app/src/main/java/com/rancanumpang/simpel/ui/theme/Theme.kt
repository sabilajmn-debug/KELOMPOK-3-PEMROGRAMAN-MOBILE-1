package com.rancanumpang.simpel.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BrandDarkGreen = Color(0xFF0A3D27)
val BrandGreen = Color(0xFF146E42)
val BrandLightGreen = Color(0xFF289E60)
val BrandGold = Color(0xFFF2B40F)

private val LightColors = lightColorScheme(
    primary = BrandGreen,
    onPrimary = Color.White,
    primaryContainer = BrandLightGreen,
    secondary = BrandGold,
    onSecondary = BrandDarkGreen,
    tertiary = BrandDarkGreen
)

private val DarkColors = darkColorScheme(
    primary = BrandLightGreen,
    onPrimary = BrandDarkGreen,
    primaryContainer = BrandGreen,
    secondary = BrandGold,
    onSecondary = BrandDarkGreen,
    tertiary = BrandLightGreen
)

@Composable
fun SimpelTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
