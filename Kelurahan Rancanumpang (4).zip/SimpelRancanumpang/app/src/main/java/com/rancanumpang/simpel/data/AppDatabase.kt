package com.rancanumpang.simpel.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [UserAccount::class, DataWarga::class, Permohonan::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun dataWargaDao(): DataWargaDao
    abstract fun permohonanDao(): PermohonanDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "simpel_rancanumpang.db"
                ).addCallback(SeedCallback(scope)).build()
                INSTANCE = instance
                instance
            }
        }
    }

    /** Mengisi data awal: akun tiap aktor & data kependudukan dasar untuk verifikasi NIK otomatis */
    private class SeedCallback(private val scope: CoroutineScope) : Callback() {
        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            super.onCreate(db)
            scope.launch(Dispatchers.IO) {
                INSTANCE?.let { database ->
                    database.dataWargaDao().insertAll(
                        listOf(
                            DataWarga("3273010101900001", "Chany Fauziah", "Jl. Rancanumpang No. 1", "01", "05"),
                            DataWarga("3273010101900002", "Salsabila Apriliyanti", "Jl. Rancanumpang No. 2", "02", "05"),
                            DataWarga("3273010101900003", "Budi Santoso", "Jl. Gedebage Indah No. 10", "03", "06", kategoriPmks = true),
                            DataWarga("3273010101900004", "Siti Aminah", "Jl. Gedebage Indah No. 12", "03", "06", kategoriPmks = true),
                            DataWarga("3273010101900005", "Agus Wijaya", "Jl. Rancanumpang No. 20", "04", "07")
                        )
                    )
                    database.userDao().insertAll(
                        listOf(
                            UserAccount("warga1", "1234", "Chany Fauziah", Role.WARGA, nik = "3273010101900001"),
                            UserAccount("warga2", "1234", "Budi Santoso", Role.WARGA, nik = "3273010101900003"),
                            UserAccount("kasipem", "1234", "Kasi Pemerintahan", Role.KASI_PEM),
                            UserAccount("kasikesos", "1234", "Kasi Kesejahteraan Sosial", Role.KASI_KESOS),
                            UserAccount("kasiekbang", "1234", "Kasi Ekonomi Pembangunan", Role.KASI_EKBANG),
                            UserAccount("petugas1", "1234", "Petugas Lapangan 1", Role.PETUGAS),
                            UserAccount("lurah", "1234", "Lurah Rancanumpang", Role.LURAH)
                        )
                    )
                }
            }
        }
    }
}
