package com.rancanumpang.simpel.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rancanumpang.simpel.data.Role
import com.rancanumpang.simpel.ui.screens.*
import com.rancanumpang.simpel.viewmodel.AuthViewModel
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@Composable
fun AppNavGraph(
    authViewModel: AuthViewModel,
    permohonanViewModel: PermohonanViewModel
) {
    val navController: NavHostController = rememberNavController()
    val currentUser by authViewModel.currentUser.collectAsState()

    NavHost(navController = navController, startDestination = Routes.LOGIN) {

        composable(Routes.LOGIN) {
            LoginScreen(
                authViewModel = authViewModel,
                onLoginSuccess = {
                    val destination = when (currentUser?.role) {
                        Role.WARGA -> Routes.WARGA_HOME
                        Role.KASI_PEM, Role.KASI_KESOS, Role.KASI_EKBANG -> Routes.KASI_HOME
                        Role.PETUGAS -> Routes.PETUGAS_HOME
                        Role.LURAH -> Routes.LURAH_HOME
                        null -> Routes.LOGIN
                    }
                    navController.navigate(destination) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        // ---------------- WARGA ----------------
        composable(Routes.WARGA_HOME) {
            val user = currentUser
            if (user != null) {
                WargaHomeScreen(
                    user = user,
                    viewModel = permohonanViewModel,
                    onAjukan = { navController.navigate(Routes.FORM_PENGAJUAN) },
                    onLacak = { navController.navigate(Routes.LACAK_STATUS) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) { popUpTo(0) }
                    }
                )
            }
        }
        composable(Routes.FORM_PENGAJUAN) {
            val user = currentUser
            if (user != null) {
                FormPengajuanScreen(
                    user = user,
                    viewModel = permohonanViewModel,
                    onBack = { navController.popBackStack() },
                    onSubmitted = { navController.popBackStack() }
                )
            }
        }
        composable(Routes.LACAK_STATUS) {
            LacakStatusScreen(
                viewModel = permohonanViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // ---------------- KASI ----------------
        composable(Routes.KASI_HOME) {
            val user = currentUser
            if (user != null) {
                KasiHomeScreen(
                    user = user,
                    viewModel = permohonanViewModel,
                    onOpenDetail = { id -> navController.navigate(Routes.detailVerifikasi(id)) },
                    onOpenLaporan = { navController.navigate(Routes.LAPORAN_BULANAN) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) { popUpTo(0) }
                    }
                )
            }
        }
        composable(
            route = Routes.DETAIL_VERIFIKASI,
            arguments = listOf(navArgument("permohonanId") { type = NavType.LongType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("permohonanId") ?: 0L
            DetailVerifikasiScreen(
                permohonanId = id,
                viewModel = permohonanViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // ---------------- PETUGAS ----------------
        composable(Routes.PETUGAS_HOME) {
            val user = currentUser
            if (user != null) {
                PetugasHomeScreen(
                    user = user,
                    viewModel = permohonanViewModel,
                    onOpenDetail = { id -> navController.navigate(Routes.detailTugas(id)) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) { popUpTo(0) }
                    }
                )
            }
        }
        composable(
            route = Routes.DETAIL_TUGAS,
            arguments = listOf(navArgument("permohonanId") { type = NavType.LongType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("permohonanId") ?: 0L
            DetailTugasScreen(
                permohonanId = id,
                viewModel = permohonanViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // ---------------- LURAH ----------------
        composable(Routes.LURAH_HOME) {
            val user = currentUser
            if (user != null) {
                LurahHomeScreen(
                    user = user,
                    viewModel = permohonanViewModel,
                    onOpenDetail = { id -> navController.navigate(Routes.detailValidasi(id)) },
                    onOpenLaporan = { navController.navigate(Routes.LAPORAN_BULANAN) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) { popUpTo(0) }
                    }
                )
            }
        }
        composable(
            route = Routes.DETAIL_VALIDASI,
            arguments = listOf(navArgument("permohonanId") { type = NavType.LongType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("permohonanId") ?: 0L
            DetailValidasiScreen(
                permohonanId = id,
                viewModel = permohonanViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // ---------------- LAPORAN (Kasi & Lurah) ----------------
        composable(Routes.LAPORAN_BULANAN) {
            LaporanBulananScreen(
                viewModel = permohonanViewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
