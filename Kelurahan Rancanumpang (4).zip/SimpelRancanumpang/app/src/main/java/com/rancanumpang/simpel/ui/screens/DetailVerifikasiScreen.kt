package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.Permohonan
import com.rancanumpang.simpel.data.StatusPermohonan
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailVerifikasiScreen(
    permohonanId: Long,
    viewModel: PermohonanViewModel,
    onBack: () -> Unit
) {
    var permohonan by remember { mutableStateOf<Permohonan?>(null) }
    var petugas by remember { mutableStateOf("petugas1") }
    var catatan by remember { mutableStateOf("") }
    val semua by viewModel.semuaPermohonan.collectAsState()

    LaunchedEffect(permohonanId, semua) {
        permohonan = semua.find { it.id == permohonanId }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detail Permohonan") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        val p = permohonan
        if (p == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(Modifier.padding(padding).padding(16.dp)) {
            Text(p.jenisLayanan.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Pemohon: ${p.namaPemohon}")
            Text("NIK: ${p.nik}")
            Text("No. Resi: ${p.nomorResi}")
            Text("Keperluan: ${p.keperluan}")
            Spacer(Modifier.height(8.dp))
            StatusBadge(status = p.status)

            Spacer(Modifier.height(24.dp))

            when (p.status) {
                StatusPermohonan.TERVERIFIKASI_NIK -> {
                    Text("Tindakan: Disposisikan ke Petugas Lapangan", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = petugas,
                        onValueChange = { petugas = it },
                        label = { Text("Username Petugas") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = catatan,
                        onValueChange = { catatan = it },
                        label = { Text("Catatan untuk petugas (opsional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                viewModel.disposisiKePetugas(p, petugas, catatan.ifBlank { null })
                                onBack()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Disposisikan") }
                        OutlinedButton(
                            onClick = {
                                viewModel.tolakOlehKasi(p, "Berkas tidak memenuhi syarat administratif")
                                onBack()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Tolak") }
                    }
                }
                StatusPermohonan.NIK_TIDAK_VALID -> {
                    Text(
                        "NIK pemohon tidak ditemukan pada database kependudukan lokal. Permohonan tidak dapat diproses.",
                        color = MaterialTheme.colorScheme.error
                    )
                }
                else -> {
                    Text("Permohonan ini sudah diproses lebih lanjut (${p.status.label}).")
                    if (!p.petugasDitugaskan.isNullOrBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Petugas: ${p.petugasDitugaskan}")
                    }
                    if (!p.catatanKasi.isNullOrBlank()) {
                        Text("Catatan: ${p.catatanKasi}")
                    }
                }
            }
        }
    }
}
