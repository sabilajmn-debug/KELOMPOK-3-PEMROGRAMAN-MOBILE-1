package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LacakStatusScreen(
    viewModel: PermohonanViewModel,
    onBack: () -> Unit
) {
    var resi by remember { mutableStateOf("") }
    val hasil by viewModel.hasilLacak.collectAsState()
    val notFound by viewModel.lacakNotFound.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lacak Status Berkas") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Masukkan nomor resi permohonan Anda:", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = resi,
                onValueChange = { resi = it },
                label = { Text("Nomor Resi (contoh: RCN-SUR-260706-1234)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { viewModel.lacakDenganResi(resi) },
                enabled = resi.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cari")
            }

            Spacer(Modifier.height(24.dp))

            if (notFound) {
                Text(
                    "Nomor resi tidak ditemukan. Periksa kembali penulisannya.",
                    color = MaterialTheme.colorScheme.error
                )
            }

            hasil?.let { p ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(p.jenisLayanan.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("No. Resi: ${p.nomorResi}")
                        Text("Pemohon: ${p.namaPemohon}")
                        Text(
                            "Tanggal Pengajuan: " +
                                SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(p.tanggalPengajuan))
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("Status saat ini:", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        StatusBadge(status = p.status)

                        if (!p.catatanKasi.isNullOrBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Text("Catatan Kasi: ${p.catatanKasi}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (!p.hasilVerifikasiLapangan.isNullOrBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Hasil Verifikasi Lapangan: ${p.hasilVerifikasiLapangan}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (!p.catatanLurah.isNullOrBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Catatan Lurah: ${p.catatanLurah}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
