package com.rancanumpang.simpel.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromRole(role: Role): String = role.name

    @TypeConverter
    fun toRole(value: String): Role = Role.valueOf(value)

    @TypeConverter
    fun fromJenisLayanan(jenis: JenisLayanan): String = jenis.name

    @TypeConverter
    fun toJenisLayanan(value: String): JenisLayanan = JenisLayanan.valueOf(value)

    @TypeConverter
    fun fromStatus(status: StatusPermohonan): String = status.name

    @TypeConverter
    fun toStatus(value: String): StatusPermohonan = StatusPermohonan.valueOf(value)
}
