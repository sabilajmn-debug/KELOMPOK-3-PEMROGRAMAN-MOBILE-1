package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.JenisLayanan
import com.rancanumpang.simpel.data.StatusPermohonan
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LaporanBulananScreen(
    viewModel: PermohonanViewModel,
    onBack: () -> Unit
) {
    val semua by viewModel.semuaPermohonan.collectAsState()

    val now = Calendar.getInstance()
    val bulanIni = remember(semua) {
        semua.filter {
            val cal = Calendar.getInstance().apply { timeInMillis = it.tanggalPengajuan }
            cal.get(Calendar.MONTH) == now.get(Calendar.MONTH) &&
                cal.get(Calendar.YEAR) == now.get(Calendar.YEAR)
        }
    }

    val totalSelesai = bulanIni.count { it.status == StatusPermohonan.SELESAI_DITERBITKAN }
    val totalDitolak = bulanIni.count { it.status == StatusPermohonan.DITOLAK_LURAH }
    val totalProses = bulanIni.size - totalSelesai - totalDitolak
    val perJenis = bulanIni.groupBy { it.jenisLayanan }.mapValues { it.value.size }
    val namaBulan = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(now.time)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Rekap Laporan Bulanan") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text(
                "Laporan Kegiatan Pelayanan — $namaBulan",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Kelurahan Rancanumpang, Kecamatan Gedebage",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RingkasanCard("Total Masuk", bulanIni.size.toString(), Modifier.weight(1f))
                RingkasanCard("Selesai", totalSelesai.toString(), Modifier.weight(1f))
                RingkasanCard("Ditolak", totalDitolak.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            RingkasanCard("Dalam Proses", totalProses.toString(), Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))
            Text("Rekapitulasi per Jenis Layanan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (perJenis.isEmpty()) {
                Text("Belum ada data permohonan pada bulan ini.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(JenisLayanan.values().filter { perJenis.containsKey(it) }) { jenis ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(jenis.label, fontWeight = FontWeight.SemiBold)
                                    Text(jenis.seksi.label, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    "${perJenis[jenis]}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Catatan: Rekap ini dikompilasi otomatis oleh sistem dari seluruh log transaksi harian, " +
                    "siap diteruskan sebagai laporan resmi ke Kecamatan Gedebage.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun RingkasanCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}
