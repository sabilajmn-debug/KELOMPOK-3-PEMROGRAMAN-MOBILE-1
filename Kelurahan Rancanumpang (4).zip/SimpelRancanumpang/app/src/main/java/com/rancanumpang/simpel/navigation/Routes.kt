package com.rancanumpang.simpel.navigation

object Routes {
    const val LOGIN = "login"
    const val WARGA_HOME = "warga_home"
    const val FORM_PENGAJUAN = "form_pengajuan"
    const val LACAK_STATUS = "lacak_status"
    const val KASI_HOME = "kasi_home"
    const val DETAIL_VERIFIKASI = "detail_verifikasi/{permohonanId}"
    const val PETUGAS_HOME = "petugas_home"
    const val DETAIL_TUGAS = "detail_tugas/{permohonanId}"
    const val LURAH_HOME = "lurah_home"
    const val DETAIL_VALIDASI = "detail_validasi/{permohonanId}"
    const val LAPORAN_BULANAN = "laporan_bulanan"

    fun detailVerifikasi(id: Long) = "detail_verifikasi/$id"
    fun detailTugas(id: Long) = "detail_tugas/$id"
    fun detailValidasi(id: Long) = "detail_validasi/$id"
}
