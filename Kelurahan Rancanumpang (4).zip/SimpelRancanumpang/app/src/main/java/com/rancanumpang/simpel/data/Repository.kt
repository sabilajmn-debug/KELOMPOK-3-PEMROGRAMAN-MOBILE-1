package com.rancanumpang.simpel.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class Repository(private val db: AppDatabase) {

    // ---------- Auth ----------
    suspend fun login(username: String, password: String): UserAccount? =
        db.userDao().login(username, password)

    // ---------- Verifikasi NIK (Use Case: Otomasi Verifikasi Administrasi Kependudukan) ----------
    suspend fun cariDataWarga(nik: String): DataWarga? = db.dataWargaDao().findByNik(nik)

    // ---------- Permohonan ----------
    fun getAllPermohonan(): Flow<List<Permohonan>> = db.permohonanDao().getAll()
    fun getPermohonanByNik(nik: String): Flow<List<Permohonan>> = db.permohonanDao().getByNik(nik)
    fun getPermohonanByPetugas(petugas: String): Flow<List<Permohonan>> =
        db.permohonanDao().getByPetugas(petugas)

    suspend fun getPermohonanByResi(resi: String): Permohonan? = db.permohonanDao().getByResi(resi)
    suspend fun getPermohonanById(id: Long): Permohonan? = db.permohonanDao().getById(id)

    /**
     * Alur utama: Warga mengajukan permohonan -> sistem verifikasi NIK otomatis
     * ke database kependudukan lokal -> jika valid, status TERVERIFIKASI_NIK,
     * jika tidak, NIK_TIDAK_VALID (sesuai Use Case Scenario "Pengajuan Permohonan Surat").
     */
    suspend fun ajukanPermohonan(
        nik: String,
        namaPemohon: String,
        jenisLayanan: JenisLayanan,
        keperluan: String
    ): Permohonan {
        val dataWarga = cariDataWarga(nik)
        val statusAwal = if (dataWarga != null) {
            StatusPermohonan.TERVERIFIKASI_NIK
        } else {
            StatusPermohonan.NIK_TIDAK_VALID
        }
        val nomorResi = generateNomorResi(jenisLayanan)
        val permohonan = Permohonan(
            nomorResi = nomorResi,
            nik = nik,
            namaPemohon = if (dataWarga != null) dataWarga.nama else namaPemohon,
            jenisLayanan = jenisLayanan,
            keperluan = keperluan,
            tanggalPengajuan = System.currentTimeMillis(),
            status = statusAwal
        )
        val id = db.permohonanDao().insert(permohonan)
        return permohonan.copy(id = id)
    }

    private fun generateNomorResi(jenis: JenisLayanan): String {
        val dateStr = SimpleDateFormat("yyMMdd", Locale.getDefault()).format(Date())
        val rand = Random.nextInt(1000, 9999)
        val prefix = jenis.name.take(3)
        return "RCN-$prefix-$dateStr-$rand"
    }

    /** Kasi mendisposisikan berkas ke petugas lapangan untuk verifikasi teknis */
    suspend fun disposisiKePetugas(permohonan: Permohonan, petugas: String, catatan: String?) {
        val updated = permohonan.copy(
            status = StatusPermohonan.DISPOSISI_PETUGAS,
            petugasDitugaskan = petugas,
            catatanKasi = catatan
        )
        db.permohonanDao().update(updated)
    }

    /** Petugas menyelesaikan verifikasi lapangan, berkas diteruskan ke Lurah */
    suspend fun selesaikanVerifikasiLapangan(permohonan: Permohonan, hasil: String) {
        val updated = permohonan.copy(
            status = StatusPermohonan.MENUNGGU_VALIDASI_LURAH,
            hasilVerifikasiLapangan = hasil
        )
        db.permohonanDao().update(updated)
    }

    /** Lurah memvalidasi (menyetujui) atau menolak berkas */
    suspend fun validasiLurah(permohonan: Permohonan, disetujui: Boolean, catatan: String?) {
        val updated = permohonan.copy(
            status = if (disetujui) StatusPermohonan.SELESAI_DITERBITKAN else StatusPermohonan.DITOLAK_LURAH,
            catatanLurah = catatan,
            tanggalSelesai = System.currentTimeMillis()
        )
        db.permohonanDao().update(updated)
    }

    /** Kasi menolak langsung tanpa disposisi (mis. berkas tidak lengkap) */
    suspend fun tolakOlehKasi(permohonan: Permohonan, catatan: String) {
        val updated = permohonan.copy(
            status = StatusPermohonan.DITOLAK_LURAH,
            catatanKasi = catatan,
            tanggalSelesai = System.currentTimeMillis()
        )
        db.permohonanDao().update(updated)
    }
}
