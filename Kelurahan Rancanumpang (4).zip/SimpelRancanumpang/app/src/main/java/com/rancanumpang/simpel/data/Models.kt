package com.rancanumpang.simpel.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Peran (aktor) sesuai Use Case Diagram:
 * Warga, Kasi Pemerintahan, Kasi Kesos, Kasi Ekbang, Petugas Lapangan, Lurah
 */
enum class Role(val label: String) {
    WARGA("Warga"),
    KASI_PEM("Kasi Pemerintahan"),
    KASI_KESOS("Kasi Kesejahteraan Sosial"),
    KASI_EKBANG("Kasi Ekonomi Pembangunan"),
    PETUGAS("Petugas Kelurahan"),
    LURAH("Lurah")
}

/** Jenis layanan/surat yang dapat diajukan warga */
enum class JenisLayanan(val label: String, val seksi: Role) {
    SURAT_PENGANTAR_KTP("Surat Pengantar KTP", Role.KASI_PEM),
    SURAT_PENGANTAR_KK("Surat Pengantar KK", Role.KASI_PEM),
    SURAT_DOMISILI("Surat Keterangan Domisili", Role.KASI_PEM),
    SURAT_MUTASI("Surat Keterangan Mutasi Warga", Role.KASI_PEM),
    SKTM("Surat Keterangan Tidak Mampu (SKTM)", Role.KASI_KESOS),
    BANSOS("Verifikasi Penerima Bansos (PKH/BPNT)", Role.KASI_KESOS),
    UMKM("Pendaftaran UMKM", Role.KASI_EKBANG),
    IZIN_USAHA_MIKRO("Izin Usaha Mikro", Role.KASI_EKBANG)
}

/** Status alur permohonan, mengikuti flow of events pada Use Case Scenario */
enum class StatusPermohonan(val label: String) {
    DIAJUKAN("Diajukan"),
    NIK_TIDAK_VALID("NIK Tidak Valid / Ditolak Sistem"),
    TERVERIFIKASI_NIK("Terverifikasi NIK"),
    DISPOSISI_PETUGAS("Didisposisikan ke Petugas"),
    VERIFIKASI_LAPANGAN("Verifikasi Lapangan Selesai"),
    MENUNGGU_VALIDASI_LURAH("Menunggu Validasi Lurah"),
    DISETUJUI_LURAH("Disetujui Lurah"),
    DITOLAK_LURAH("Ditolak Lurah"),
    SELESAI_DITERBITKAN("Selesai / Dokumen Diterbitkan")
}

/** Akun pengguna sistem (dummy auth lokal, sesuai aktor use case) */
@Entity(tableName = "users")
data class UserAccount(
    @PrimaryKey val username: String,
    val password: String,
    val nama: String,
    val role: Role,
    val nik: String? = null // hanya untuk role WARGA
)

/**
 * Data dasar kependudukan lokal kelurahan, digunakan untuk verifikasi NIK
 * otomatis (poin "Otomasi Verifikasi Administrasi Kependudukan").
 */
@Entity(tableName = "data_warga")
data class DataWarga(
    @PrimaryKey val nik: String,
    val nama: String,
    val alamat: String,
    val rt: String,
    val rw: String,
    val kategoriPmks: Boolean = false // penanda DTKS/PMKS untuk Kasi Kesos
)

/** Entitas inti: permohonan/berkas warga yang mengalir lintas aktor */
@Entity(tableName = "permohonan")
data class Permohonan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nomorResi: String,
    val nik: String,
    val namaPemohon: String,
    val jenisLayanan: JenisLayanan,
    val keperluan: String,
    val tanggalPengajuan: Long,
    var status: StatusPermohonan = StatusPermohonan.DIAJUKAN,
    var catatanKasi: String? = null,
    var petugasDitugaskan: String? = null,
    var hasilVerifikasiLapangan: String? = null,
    var catatanLurah: String? = null,
    var tanggalSelesai: Long? = null
)
