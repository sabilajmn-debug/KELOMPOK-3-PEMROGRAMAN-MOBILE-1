package com.rancanumpang.simpel.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rancanumpang.simpel.data.Repository
import com.rancanumpang.simpel.data.UserAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AuthViewModel(private val repository: Repository) : ViewModel() {

    private val _currentUser = MutableStateFlow<UserAccount?>(null)
    val currentUser: StateFlow<UserAccount?> = _currentUser

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val user = repository.login(username.trim(), password.trim())
            if (user != null) {
                _currentUser.value = user
                _loginError.value = null
            } else {
                _loginError.value = "Username atau password salah."
            }
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    fun clearError() {
        _loginError.value = null
    }
}
