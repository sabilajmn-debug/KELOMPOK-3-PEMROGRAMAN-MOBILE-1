package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.JenisLayanan
import com.rancanumpang.simpel.data.UserAccount
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormPengajuanScreen(
    user: UserAccount,
    viewModel: PermohonanViewModel,
    onBack: () -> Unit,
    onSubmitted: () -> Unit
) {
    var jenisExpanded by remember { mutableStateOf(false) }
    var jenisTerpilih by remember { mutableStateOf(JenisLayanan.SURAT_PENGANTAR_KTP) }
    var keperluan by remember { mutableStateOf("") }
    val nik = user.nik ?: ""

    val lastSubmitted by viewModel.lastSubmitted.collectAsState()

    LaunchedEffect(lastSubmitted) {
        if (lastSubmitted != null) {
            viewModel.clearLastSubmitted()
            onSubmitted()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ajukan Permohonan Surat") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Data Pemohon", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = user.nama,
                onValueChange = {},
                readOnly = true,
                label = { Text("Nama") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = nik,
                onValueChange = {},
                readOnly = true,
                label = { Text("NIK") },
                supportingText = { Text("NIK akan diverifikasi otomatis oleh sistem terhadap database kependudukan.") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Text("Jenis Layanan", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ExposedDropdownMenuBox(
                expanded = jenisExpanded,
                onExpandedChange = { jenisExpanded = it }
            ) {
                OutlinedTextField(
                    value = jenisTerpilih.label,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Pilih jenis surat/layanan") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = jenisExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = jenisExpanded,
                    onDismissRequest = { jenisExpanded = false }
                ) {
                    JenisLayanan.values().forEach { jenis ->
                        DropdownMenuItem(
                            text = { Text("${jenis.label} (${jenis.seksi.label})") },
                            onClick = {
                                jenisTerpilih = jenis
                                jenisExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = keperluan,
                onValueChange = { keperluan = it },
                label = { Text("Keperluan / Keterangan") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    viewModel.ajukanPermohonan(nik, user.nama, jenisTerpilih, keperluan)
                },
                enabled = keperluan.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Kirim Permohonan")
            }
        }
    }
}
