package com.rancanumpang.simpel.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rancanumpang.simpel.data.DataWarga
import com.rancanumpang.simpel.data.JenisLayanan
import com.rancanumpang.simpel.data.Permohonan
import com.rancanumpang.simpel.data.Repository
import com.rancanumpang.simpel.data.StatusPermohonan
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PermohonanViewModel(private val repository: Repository) : ViewModel() {

    val semuaPermohonan: StateFlow<List<Permohonan>> = repository.getAllPermohonan()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _permohonanSaya = MutableStateFlow<List<Permohonan>>(emptyList())
    val permohonanSaya: StateFlow<List<Permohonan>> = _permohonanSaya

    private val _lastSubmitted = MutableStateFlow<Permohonan?>(null)
    val lastSubmitted: StateFlow<Permohonan?> = _lastSubmitted

    private val _hasilLacak = MutableStateFlow<Permohonan?>(null)
    val hasilLacak: StateFlow<Permohonan?> = _hasilLacak

    private val _lacakNotFound = MutableStateFlow(false)
    val lacakNotFound: StateFlow<Boolean> = _lacakNotFound

    fun muatPermohonanWarga(nik: String) {
        viewModelScope.launch {
            repository.getPermohonanByNik(nik).collect { list ->
                _permohonanSaya.value = list
            }
        }
    }

    fun ajukanPermohonan(nik: String, nama: String, jenis: JenisLayanan, keperluan: String) {
        viewModelScope.launch {
            val hasil = repository.ajukanPermohonan(nik, nama, jenis, keperluan)
            _lastSubmitted.value = hasil
        }
    }

    fun lacakDenganResi(nomorResi: String) {
        viewModelScope.launch {
            val hasil = repository.getPermohonanByResi(nomorResi.trim())
            _hasilLacak.value = hasil
            _lacakNotFound.value = hasil == null
        }
    }

    fun clearLastSubmitted() {
        _lastSubmitted.value = null
    }

    fun disposisiKePetugas(permohonan: Permohonan, petugas: String, catatan: String?) {
        viewModelScope.launch {
            repository.disposisiKePetugas(permohonan, petugas, catatan)
        }
    }

    fun tolakOlehKasi(permohonan: Permohonan, catatan: String) {
        viewModelScope.launch {
            repository.tolakOlehKasi(permohonan, catatan)
        }
    }

    fun selesaikanVerifikasiLapangan(permohonan: Permohonan, hasil: String) {
        viewModelScope.launch {
            repository.selesaikanVerifikasiLapangan(permohonan, hasil)
        }
    }

    fun validasiLurah(permohonan: Permohonan, disetujui: Boolean, catatan: String?) {
        viewModelScope.launch {
            repository.validasiLurah(permohonan, disetujui, catatan)
        }
    }

    suspend fun cariDataWarga(nik: String): DataWarga? = repository.cariDataWarga(nik)

    fun permohonanUntukSeksi(list: List<Permohonan>, seksi: com.rancanumpang.simpel.data.Role): List<Permohonan> =
        list.filter { it.jenisLayanan.seksi == seksi && it.status != StatusPermohonan.NIK_TIDAK_VALID }
}
