package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.UserAccount
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KasiHomeScreen(
    user: UserAccount,
    viewModel: PermohonanViewModel,
    onOpenDetail: (Long) -> Unit,
    onOpenLaporan: () -> Unit,
    onLogout: () -> Unit
) {
    val semua by viewModel.semuaPermohonan.collectAsState()
    val daftar = remember(semua, user.role) { viewModel.permohonanUntukSeksi(semua, user.role) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(user.role.label) },
                actions = {
                    TextButton(onClick = onLogout) { Text("Keluar") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Halo, ${user.nama}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(12.dp))
            Button(onClick = onOpenLaporan, modifier = Modifier.fillMaxWidth()) {
                Text("Lihat Rekap Laporan Bulanan")
            }

            Spacer(Modifier.height(20.dp))
            Text("Permohonan Masuk (${daftar.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (daftar.isEmpty()) {
                Text("Belum ada permohonan pada seksi Anda.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(daftar) { p ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onOpenDetail(p.id) }
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.jenisLayanan.label, fontWeight = FontWeight.SemiBold)
                                Text("Pemohon: ${p.namaPemohon}", style = MaterialTheme.typography.bodySmall)
                                Text("No. Resi: ${p.nomorResi}", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(6.dp))
                                StatusBadge(status = p.status)
                            }
                        }
                    }
                }
            }
        }
    }
}
