package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.Permohonan
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailTugasScreen(
    permohonanId: Long,
    viewModel: PermohonanViewModel,
    onBack: () -> Unit
) {
    var permohonan by remember { mutableStateOf<Permohonan?>(null) }
    var hasil by remember { mutableStateOf("") }
    val semua by viewModel.semuaPermohonan.collectAsState()

    LaunchedEffect(permohonanId, semua) {
        permohonan = semua.find { it.id == permohonanId }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Verifikasi Lapangan") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        val p = permohonan
        if (p == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(Modifier.padding(padding).padding(16.dp)) {
            Text(p.jenisLayanan.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Pemohon: ${p.namaPemohon}")
            Text("NIK: ${p.nik}")
            Text("Keperluan: ${p.keperluan}")
            if (!p.catatanKasi.isNullOrBlank()) {
                Text("Catatan Kasi: ${p.catatanKasi}")
            }
            Spacer(Modifier.height(8.dp))
            StatusBadge(status = p.status)

            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = hasil,
                onValueChange = { hasil = it },
                label = { Text("Hasil pemeriksaan / catatan lapangan") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    viewModel.selesaikanVerifikasiLapangan(p, hasil.ifBlank { "Sesuai kondisi lapangan" })
                    onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Kirim Hasil ke Lurah")
            }
        }
    }
}
