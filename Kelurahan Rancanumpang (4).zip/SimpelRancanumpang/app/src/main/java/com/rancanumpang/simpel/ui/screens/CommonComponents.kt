package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.StatusPermohonan

@Composable
fun StatusBadge(status: StatusPermohonan) {
    val color = when (status) {
        StatusPermohonan.DIAJUKAN -> Color(0xFF90A4AE)
        StatusPermohonan.NIK_TIDAK_VALID -> Color(0xFFD32F2F)
        StatusPermohonan.TERVERIFIKASI_NIK -> Color(0xFF1976D2)
        StatusPermohonan.DISPOSISI_PETUGAS -> Color(0xFF7B1FA2)
        StatusPermohonan.VERIFIKASI_LAPANGAN -> Color(0xFF00838F)
        StatusPermohonan.MENUNGGU_VALIDASI_LURAH -> Color(0xFFF57C00)
        StatusPermohonan.DISETUJUI_LURAH -> Color(0xFF388E3C)
        StatusPermohonan.DITOLAK_LURAH -> Color(0xFFD32F2F)
        StatusPermohonan.SELESAI_DITERBITKAN -> Color(0xFF2E7D32)
    }
    Text(
        text = status.label,
        color = Color.White,
        style = MaterialTheme.typography.labelMedium,
        modifier = Modifier
            .background(color, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
