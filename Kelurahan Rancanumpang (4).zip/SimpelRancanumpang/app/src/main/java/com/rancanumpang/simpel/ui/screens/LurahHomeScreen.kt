package com.rancanumpang.simpel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rancanumpang.simpel.data.StatusPermohonan
import com.rancanumpang.simpel.data.UserAccount
import com.rancanumpang.simpel.viewmodel.PermohonanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LurahHomeScreen(
    user: UserAccount,
    viewModel: PermohonanViewModel,
    onOpenDetail: (Long) -> Unit,
    onOpenLaporan: () -> Unit,
    onLogout: () -> Unit
) {
    val semua by viewModel.semuaPermohonan.collectAsState()
    val menunggu = remember(semua) { semua.filter { it.status == StatusPermohonan.MENUNGGU_VALIDASI_LURAH } }
    val riwayat = remember(semua) {
        semua.filter { it.status == StatusPermohonan.SELESAI_DITERBITKAN || it.status == StatusPermohonan.DITOLAK_LURAH }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Beranda Lurah") },
                actions = { TextButton(onClick = onLogout) { Text("Keluar") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Halo, ${user.nama}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(12.dp))
            Button(onClick = onOpenLaporan, modifier = Modifier.fillMaxWidth()) {
                Text("Lihat Rekap Laporan Bulanan")
            }

            Spacer(Modifier.height(20.dp))
            Text("Menunggu Validasi (${menunggu.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (menunggu.isEmpty()) {
                Text("Tidak ada berkas yang menunggu validasi.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(menunggu) { p ->
                        Card(onClick = { onOpenDetail(p.id) }) {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.jenisLayanan.label, fontWeight = FontWeight.SemiBold)
                                Text("Pemohon: ${p.namaPemohon}", style = MaterialTheme.typography.bodySmall)
                                Text("No. Resi: ${p.nomorResi}", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(6.dp))
                                StatusBadge(status = p.status)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Riwayat Keputusan (${riwayat.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (riwayat.isEmpty()) {
                Text("Belum ada riwayat keputusan.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(riwayat) { p ->
                        Card {
                            Column(Modifier.padding(14.dp)) {
                                Text(p.jenisLayanan.label, fontWeight = FontWeight.SemiBold)
                                Text("Pemohon: ${p.namaPemohon}", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(6.dp))
                                StatusBadge(status = p.status)
                            }
                        }
                    }
                }
            }
        }
    }
}
